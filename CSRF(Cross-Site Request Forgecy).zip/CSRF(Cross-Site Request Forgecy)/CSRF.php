<?php

/**
 * generate CSRF token
 * 
 * @author  Joe Sexton <joe@webtipblog.com>
 * @param   string $formName
 * @return  string  
 */
function generateToken( $formName ) 
{
    $secretKey = 'gsfhs154aergz2#';
    if ( !session_id() ) {
        session_start();
    }
    $sessionId = session_id();
 
    return sha1( $formName.$sessionId.$secretKey );
 
}
/**
 * check CSRF token
 * 
 * @author  Joe Sexton <joe@webtipblog.com>
 * @param   string $token
 * @param   string $formName
 * @return  boolean  
 */
function checkToken( $token, $formName ) 
{
    return $token === generateToken( $formName );
}
if ( !empty( $_POST['csrf_token'] ) ) {
 
    if( checkToken( $_POST['csrf_token'], 'protectedForm' ) ) {
        // valid form, continue
    }
 
} // end if
?>
<form name="SecureForm" method="POST">
    <input type="hidden" name="csrf_token" value="<?php echo generateToken('protectedForm'); ?>" /><br><br>
    <input type="submit" value="Check Request" />
</form>
